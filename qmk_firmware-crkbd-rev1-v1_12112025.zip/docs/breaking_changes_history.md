# Past Breaking Changes

This page links to all previous changelogs from the QMK Breaking Changes process.

* [2025 Aug 31](ChangeLog/20250831) - version 0.30.0
* [2025 May 25](ChangeLog/20250525) - version 0.29.0
* [2025 Feb 23](ChangeLog/20250223) - version 0.28.0
* [2024 Nov 24](ChangeLog/20241124) - version 0.27.0
* [2024 Aug 25](ChangeLog/20240825) - version 0.26.0
* [2024 May 26](ChangeLog/20240526) - version 0.25.0
* [2024 Feb 25](ChangeLog/20240225) - version 0.24.0
* [2023 Nov 26](ChangeLog/20231126) - version 0.23.0
* [2023 Aug 27](ChangeLog/20230827) - version 0.22.0
* [2023 May 28](ChangeLog/20230528) - version 0.21.0
* [2023 Feb 26](ChangeLog/20230226) - version 0.20.0
* [2022 Nov 26](ChangeLog/20221126) - version 0.19.0
* [2022 Aug 27](ChangeLog/20220827) - version 0.18.0
* [2022 May 28](ChangeLog/20220528) - version 0.17.0
* [2022 Feb 26](ChangeLog/20220226) - version 0.16.0
* [2021 Nov 27](ChangeLog/20211127) - version 0.15.0
* [2021 Aug 28](ChangeLog/20210828) - version 0.14.0
* [2021 May 29](ChangeLog/20210529) - version 0.13.0
* [2021 Feb 27](ChangeLog/20210227) - version 0.12.0
* [2020 Nov 28](ChangeLog/20201128) - version 0.11.0
* [2020 Aug 29](ChangeLog/20200829) - version 0.10.0
* [2020 May 30](ChangeLog/20200530) - version 0.9.0
* [2020 Feb 29](ChangeLog/20200229) - version 0.8.0
* [2019 Aug 30](ChangeLog/20190830) - version 0.7.0
